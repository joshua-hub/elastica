/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 10 Baumgardt 0123456

  Program as10_finitediff (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.

  About: This program uses finite differences to solve the Elastica 
         boundary value problem. Since the Elastica problem is non-linear,
         the Newton-Raphson is used to iterate towards the true solution.

  Compile: gcc -Wall -lm as10_finitediff.c -o as10_finitediff

  Input: The pressure P, the number of steps N_Step and the name of the file
         where output is stored in

  Output: The maximum elongation ymax
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

#define PI   3.1415927

int main() {
 int i,j,err,nstep;
 double p,h,maxdiff,x=0.0,y=0.0;
 double *diag,*a,*c,*theta,*dtheta,*rhs;
 double ymax;
 int tridiag();
 FILE *outdat;
 char fname[100]; 

// Read data form the user
 fprintf(stderr,"Input filename: ");
 fgets(fname,100,stdin);
 fname[strlen(fname)-1]='\0';

 printf("Input pressure: ");
 scanf("%lf",&p);

 printf("Input number of steps: ");
 scanf("%i",&nstep);

 printf("\n");

// Set stepsize h
 h = 1.0/(1.0*nstep);

 theta = malloc((nstep-1)*sizeof(double));   // Allocate vectors, we will need nstep-1 elements
 rhs   = malloc((nstep-1)*sizeof(double));   // since we have nstep-1 equations
 diag  = malloc((nstep-1)*sizeof(double));
 a     = malloc((nstep-1)*sizeof(double));
 c     = malloc((nstep-1)*sizeof(double));
 dtheta= malloc((nstep-1)*sizeof(double));

// Setting initial guess - Note that y[0] and y[1] will not be part of this array
 for (i=0;i<nstep-1;i++)
     theta[i]=2.0*sin(2.0*PI*(i+1.0)/(1.0*nstep+1));

 j = 0;

 do { 
   j++;

// Set right-hand side vector
   rhs[0] = -2.0*theta[0]+theta[1]+h*h*p*sin(theta[0]);
   rhs[nstep-2] = theta[nstep-3]-2.0*theta[nstep-2]+h*h*p*sin(theta[nstep-2]);

   for (i=0;i<nstep-2;i++) 
      rhs[i] = theta[i-1]-2.0*theta[i]+theta[i+1]+h*h*p*sin(theta[i]);

// Set diagonal elements of matrix J as well as the elements above and below
// the diagonal
   for (i=0;i<nstep-1;i++) diag[i]=-2.0+h*h*p*cos(theta[i]);
   for (i=0;i<nstep-1;i++) a[i]=1.0;
   for (i=0;i<nstep-1;i++) c[i]=1.0;

// Solve matrix equation by using function tridiag
   err =  tridiag(diag, a, c, rhs, dtheta, nstep-1);    

// Check if error occurred
   if (err != 0) {
     printf("Error in tridiag !\n");
     exit(-1);
   }  

// Correct initial solution
   for (i=0;i<nstep-1;i++) theta[i] -= dtheta[i];

// Check if maximum change is below threshold, if so stop 
   maxdiff = 0.0;
   for (i=0;i<nstep-1;i++)
     if (maxdiff<fabs(dtheta[i])) maxdiff=fabs(dtheta[i]);

   printf("Iteration: %i  Maximum difference: %lf\n",j,maxdiff);
 } while (maxdiff>1.E-5);


// Print out result and check for maximum elongation
 outdat=fopen(fname,"w");

 fprintf(outdat,"%lf %lf %lf %lf\n",0.0,0.0,0.0,0.0);

 ymax=0.0;
 for (i=0;i<nstep-1;i++) { 
   x += cos(theta[i])*h;
   y += sin(theta[i])*h;
   fprintf(outdat,"%lf %lf %lf %lf\n",(i+1)*h,theta[i],x,y);
   if (ymax<fabs(y)) ymax=fabs(y);
 } 

 x += cos(theta[i-1])*h;
 y += sin(theta[i-1])*h;

 fprintf(outdat,"%lf %lf %lf %lf\n",1.0,0.0,x,y);
 fclose(outdat);

 fprintf(stderr,"\nMaximum elongation: %lf\n",ymax); 

 exit(0);
}

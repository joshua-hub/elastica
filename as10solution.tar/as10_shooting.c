/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 10 Baumgardt 0123456
 
  Program as10_shooting (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This program uses the shooting method to solve the Elastica problem. 
         It uses the midpoint method for the integration and the bisection 
         method for root finding.
 
  Compile: gcc -Wall -lm as10_shooting.c -o as10_shooting
 
  Input: The pressure P, stepsize ds and the filename where output is stored in   
 
  Output: The maximum elongation ymax
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

double p;
double *theta_arr;

int main() {
 int i=0,iloop=0;
 double ds,dtheta,dtheta1,dtheta2,thetaf,thetaf1,thetaf2;
 double x=0.0,y=0.0;
 double midpoint_driver();
 double ymax;
 char fname[100];
 FILE *outdat;

// Ask user for filename, pressure and step size
 fprintf(stderr,"Input filename: ");
 fgets(fname,100,stdin);
 fname[strlen(fname)-1]='\0';   // Remove final CR from filename

 fprintf(stderr,"Input pressure: ");
 scanf("%lf",&p);

 fprintf(stderr,"Input stepsize: ");
 scanf("%lf",&ds);

 theta_arr=malloc(1.1/ds*sizeof(double)); // Create theta array

 theta_arr[0]=0.0;

 dtheta1 = 0.5;                          // Start value for lower bound
 thetaf1 = midpoint_driver(dtheta1,0.5,ds);
 
 dtheta2 = 30.0;                         // Start value for upper bound
 thetaf2 = midpoint_driver(dtheta2,0.5,ds);

 if (thetaf1*thetaf2>0.0) {              // Make sure we are on different sides of the root
   printf("Both angles have same sign !\n");
   exit(-1);
 }


// Use bisection to find root
 do {
    dtheta = (dtheta1+dtheta2)/2.0;
    thetaf = midpoint_driver(dtheta,0.5,ds);
    if (thetaf*thetaf1>0.0) {
       dtheta1=dtheta;
    } else {
       dtheta2=dtheta;
    } 
    iloop++;
 } while (fabs(dtheta2-dtheta1)>1E-10 && iloop<100);

 if (iloop>=100) {
   printf("\nNo solution found\n");
   exit(-1);
 }

// Integrate one final time up to 1.0 to get output values
 ds = 0.001;
 thetaf = midpoint_driver(dtheta2,1.0,ds);

 outdat = fopen(fname,"w");

 ymax = 0.0;
 do { 
   fprintf(outdat,"%lf %lf %lf %lf\n",i*ds,theta_arr[i],x,y);
   x += cos(theta_arr[i])*ds;    // Use Euler method for x and y 
   y += sin(theta_arr[i])*ds;
   if (y>ymax) ymax=y;
   i++;
 } while (i*ds<=1.0);

 fprintf(stderr,"Maximum elongation: %lf\n",ymax);
 
 fclose(outdat);

 exit(0);
}

double midpoint_driver(double t, double smax, double ds) {
  double s=0.0;
  double dtds,dthetads;
  int i=0;

  do { 
// Derivatives at the start the step 
    dthetads = t;
    dtds     = -p*sin(theta_arr[i]);

// Use midpoint values to make the full step
    theta_arr[i+1]=theta_arr[i]+(t+0.5*dtds*ds)*ds;
    t += -p*sin(theta_arr[i]+0.5*dthetads*ds)*ds;

    i++;
    s += ds;
  } while (s<=smax);

  return theta_arr[i];
}
